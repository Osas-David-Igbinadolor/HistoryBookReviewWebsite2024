<?php
namespace App\Models;

use CodeIgniter\Model;

class NewsModel extends Model
{
    protected $table = 'news';
    protected $primaryKey = 'id'; // Assuming the primary key is 'id'
    protected $allowedFields = ['title', 'slug', 'body'];

    public function getNews($slug = false)
    {
        if ($slug === false) {
            // If no slug is provided, fetch all news items.
            return $this->findAll();
        }

        // Fetch a single news item by its slug.
        return $this->where('slug', $slug)->first();
    }
}
