<?php

namespace App\Controllers;

use App\Models\BookModel; // Import the BookModel

class Home extends BaseController
{
    public function index()
    {
        return view('home/index', ['title' => 'Welcome to History Book Reviews']);
    }

    public function books()
    {
        $bookModel = new BookModel();
        $books = $bookModel->findAll(); // Fetch all books from the database

        return view('books/index', ['title' => 'Book Listings', 'books' => $books]);
    }

    // API endpoint to retrieve book data
    public function apiBooks()
    {
        $bookModel = new BookModel();
        $books = $bookModel->findAll(); // Fetch all books from the database

        return $this->response->setJSON($books);
    }
}
