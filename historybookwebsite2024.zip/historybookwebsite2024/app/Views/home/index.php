<?php include(APPPATH . 'Views/layout/navbar.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <!-- Navbar included using APPPATH constant -->
    <div class="container">
        <h1>Welcome to the Homepage</h1>
        <!-- Add your homepage content here -->
    </div>
</body>
</html>
