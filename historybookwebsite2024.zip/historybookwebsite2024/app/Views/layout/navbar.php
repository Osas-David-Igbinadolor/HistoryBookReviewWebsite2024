<!-- app/Views/layout/navbar.php -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="<?= site_url('/') ?>">History Book Review Site</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link<?= current_url(true)->getPath() === '/' ? ' active' : '' ?>" href="<?= site_url('/') ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link<?= current_url(true)->getPath() === 'books' ? ' active' : '' ?>" href="<?= site_url('/books') ?>">Books</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link<?= current_url(true)->getPath() === 'authors' ? ' active' : '' ?>" href="<?= site_url('/authors') ?>">Authors</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link<?= current_url(true)->getPath() === 'about' ? ' active' : '' ?>" href="<?= site_url('/about') ?>">About</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
